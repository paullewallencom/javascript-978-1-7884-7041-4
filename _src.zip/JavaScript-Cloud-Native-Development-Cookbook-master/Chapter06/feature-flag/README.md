# Leveraging feature flags

## How to do it...
1. sls create --template-url https://github.com/danteinc/js-cloud-native-cookbook/tree/master/ch6/feature-flag --path cncb-feature-flag
2. cd cncb-feature-flag
3. npm install
4. Update src/configuration.js
5. npm start
6. Click Sign In and complete form
7. Note rendered data
