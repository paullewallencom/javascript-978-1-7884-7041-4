# Writing unit tests

## How to do it...
1. sls create --template-url https://github.com/danteinc/js-cloud-native-cookbook/tree/master/ch6/unit-testing --path cncb-unit-testing
2. cd cncb-unit-testing
3. npm install
4. npm test
