---
title: "Fifth post"
date: "2017-01-05"
layout: hero
---

Another post that have a [link to the first one](../first-post/).

An wrong link to [a post that does not exist](../unknown-post/) and another one
to [a page that does not exist](/unknown-page/).

Here is an [external link](http://phenomic.io).
