module.exports.thingTypeDefs = require('./typedefs');
module.exports.thingResolvers = require('./resolvers');
module.exports.Thing = require('./model');
