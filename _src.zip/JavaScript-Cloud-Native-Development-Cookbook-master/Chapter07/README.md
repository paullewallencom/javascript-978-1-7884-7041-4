# Optimizing Observability

1.	[Monitoring a cloud-native system](./datadog-account)
2.	[Implementing custom metrics](./custom-metrics)
3.	[Monitoring domain events](./event-metrics)
4.	[Creating alerts](README.md)
5.	[Creating synthetic transaction tests](./synthetics)
